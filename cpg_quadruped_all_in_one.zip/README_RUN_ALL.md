
# CPG Quadruped Package (Pure + Sensor-Augmented)

This folder contains everything you need to **run, reproduce, and view all figures**.

## Contents
- `cpg_quadruped_trot.py` — Pure Kuramoto CPG (no sensors).  
- `cpg_with_sensors_from_dataset.py` — Sensor-augmented CPG that ingests a CSV dataset.  
- `demo_gait_dataset.csv` — Small example dataset with contacts & joint angles.  
- `BioInspired_CPG_Report.pdf` — Master’s-level report ready to submit/print.  
- `images/` — All figures saved as PNGs from both runs.

## Quick Start
```bash
pip install numpy pandas matplotlib
# Pure CPG (no sensors) — will show plots interactively
python cpg_quadruped_trot.py

# Sensor-augmented CPG using the demo dataset
python cpg_with_sensors_from_dataset.py --csv demo_gait_dataset.csv
```

Figures are also pre-generated under `images/`:
- `pure_cpg_phases.png`, `pure_cpg_footfall.png`, `pure_cpg_hip.png`, `pure_cpg_knee.png`
- `sensor_cpg_phases.png`, `sensor_cpg_footfall.png`

## Dataset format
Minimum column: `time` (seconds). Optional columns (any subset):
- Contacts (0/1): `contact_LF`, `contact_RF`, `contact_LH`, `contact_RH`
- Joints (rad or deg; deg auto-converted): `hip_*`, `knee_*`
- IMU (optional): `imu_ax`, `imu_ay`, `imu_az`, `imu_gx`, `imu_gy`, `imu_gz`

## Notes
- All plots use **matplotlib** (one chart per figure).
- The sensor-augmented controller performs: phase resetting at contact events, frequency adaptation to observed step period, and small phase-slip correction from hips (if present).
